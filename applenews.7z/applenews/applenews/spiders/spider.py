from applenews.items import ApplenewsItem
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from bs4 import BeautifulSoup

import scrapy



class AppleNewsSpider(CrawlSpider):

	name = 'applenews'

	allowed_domains = ['tw.appledaily.com', 'tw.news.appledaily.com', 'tw.entertainment.appledaily.com', 'tw.lifestyle.appledaily.com', 'tw.sports.appledaily.com', 'tw.finance.appledaily.com']
	
	start_urls = ['https://tw.appledaily.com/new/realtime']
	
	rules = [Rule(LinkExtractor(allow=('/new/realtime/')), callback = 'parse_list', follow = True)]
	
#	appleitem = ApplenewsItem()
	
	def parse_list(self, response):
#		domain = 'https://tw.appledaily.com'
		res = BeautifulSoup(response.body)
		
		for news in res.select('.rtddt'):
			yield scrapy.Request(news.select('a')[0]['href'], self.parse_detail)
			

	def parse_detail(self, response):
		res = BeautifulSoup(response.body)
		
		appleitem = ApplenewsItem()

		appleitem['date'] = response.xpath('//hgroup/div[contains(@class, "ndArticle_creat")]/text()').extract()
		
		appleitem['title'] = response.xpath('//hgroup/h1/text()').extract()

		appleitem['url'] = response.xpath('//@href')[1].extract()
		
		appleitem['view'] = response.xpath('//hgroup/div[contains(@class, "ndArticle_view")]/text()').extract()
		
		appleitem['category'] = response.xpath('//script[contains(@type, "application/ld+json")]/text()').extract()
		
		
		for x in appleitem:
			if len(appleitem[x]) == 0:
				return
			appleitem[x] = ''.join(appleitem[x])
			return appleitem
		

		